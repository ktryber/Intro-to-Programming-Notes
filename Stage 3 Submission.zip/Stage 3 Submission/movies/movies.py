title
storyline
poster_image
trailer_youtube

def show_trailer(title, youtube_url):


def show_info():
    
